
test = 'strUserID=8521095lolo&strPassword=xCdbd6507xxx00zxa69'
# test = 'strUserID=9181100wemali2&strPassword=W3m4banK2oi8'
# test = 'strUserID=39276684polari&strPassword=Dczg3877000000'
# test = 'strUserID=39276684standa&strPassword=Lvbjd351x'

# test = 'strUserID=8521095lolo&strPassword=xCdbd6507xxx00zxa'
# test = 'strUserID=39276684standa&strPassword=Lvbjd351xx000'
# test = 'strUserID=902988access1&strPassword=Owfhd065x'
# test = 'strUserID=39276684skycap&strPassword=xFaxb5234'
# test = 'strUserID=39276684ecoban&strPassword=Amwo83160X'